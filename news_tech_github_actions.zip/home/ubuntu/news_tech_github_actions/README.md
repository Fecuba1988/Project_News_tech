# Automação de Newsletter Diária com GitHub Actions

Este projeto foi modificado para ser executado automaticamente e diariamente usando o **GitHub Actions**, uma ferramenta de Integração Contínua/Entrega Contínua (CI/CD) gratuita do GitHub.

O script original que continha um *loop* infinito (`03.news_tech.py`) foi substituído por um novo arquivo chamado `main.py`, que executa a newsletter uma única vez e encerra, o que é o comportamento ideal para um ambiente de automação como o GitHub Actions.

## 1. Estrutura do Projeto

A estrutura de arquivos que você deve enviar para o seu repositório GitHub é a seguinte:

```
news_financeira/
├── .github/
│   └── workflows/
│       └── daily_newsletter.yml  <-- Arquivo de configuração do GitHub Actions
├── .gitignore
├── main.py                     <-- Novo script principal de execução única
├── prompt.py                   <-- O prompt HTML da newsletter
└── requirements.txt            <-- Dependências do Python
```

## 2. Configuração no GitHub

Para que a automação funcione, você precisará criar um novo repositório no GitHub e configurar as variáveis de ambiente como **Secrets** (Segredos) do repositório.

### Passo 1: Criar o Repositório

1.  Crie um novo repositório público ou privado no GitHub (ex: `newsletter-tech-ia`).
2.  Faça o *upload* de todos os arquivos e pastas contidos no `news_financeira` para a raiz deste novo repositório.

### Passo 2: Configurar os Secrets do Repositório

O GitHub Actions usa **Secrets** para armazenar informações sensíveis (como chaves de API e senhas) de forma segura.

1.  No seu repositório, vá para **Settings** (Configurações).
2.  No menu lateral, clique em **Security** (Segurança) > **Secrets and variables** (Segredos e variáveis) > **Actions**.
3.  Clique em **New repository secret** (Novo segredo do repositório) e adicione os seguintes segredos, um por um:

| Nome do Secret | Descrição | Exemplo de Valor |
| :--- | :--- | :--- |
| `OPENAI_API_KEY` | Sua chave de API para o modelo GPT. | `sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` |
| `TAVILY_API_KEY` | Sua chave de API para a ferramenta de busca Tavily. | `tvly-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` |
| `EMAIL_ADDRESS` | O endereço de e-mail que enviará a newsletter (remetente). | `seu.email@gmail.com` |
| `EMAIL_PASSWORD` | A senha de aplicativo (App Password) do seu e-mail. **Importante:** Se você usa Gmail, você deve gerar uma [Senha de Aplicativo] em vez da sua senha normal. | `abcd efgh ijkl mnop` |
| `DESTINATARIOS` | A lista de e-mails dos destinatários, separados por vírgula. | `destinatario1@email.com, destinatario2@email.com` |

> **Nota sobre Senha de Aplicativo (Gmail):** Para usar o Gmail com `smtplib`, você precisa ativar a verificação em duas etapas e, em seguida, gerar uma "Senha de Aplicativo" específica para este projeto. A senha de aplicativo é usada no lugar da sua senha normal.

## 3. Como Funciona a Automação

O arquivo `.github/workflows/daily_newsletter.yml` configura a automação:

*   **Gatilho Diário (`schedule`):** O script está configurado para rodar todos os dias às **10:00 AM (UTC)**. Você pode editar o arquivo `daily_newsletter.yml` para ajustar o horário se necessário.
    ```yaml
    on:
      schedule:
        - cron: '0 10 * * *' # 10:00 AM UTC
    ```
*   **Gatilho Manual (`workflow_dispatch`):** Você pode iniciar a newsletter manualmente a qualquer momento.
    1.  No seu repositório, vá para a aba **Actions** (Ações).
    2.  Clique no workflow **Daily Newsletter** no menu lateral.
    3.  Clique no botão **Run workflow** (Executar workflow) e depois em **Run workflow** novamente.

Após a execução, você pode verificar o status e os logs do envio na mesma aba **Actions**.

## 4. Próximos Passos

1.  Faça o *upload* do conteúdo do arquivo compactado que estou anexando.
2.  Configure os 5 **Secrets** no seu repositório GitHub.
3.  Aguarde o horário agendado ou acione o workflow manualmente para testar.

Qualquer dúvida sobre a configuração, estou à disposição!
"""
